//Функция для автарки а точнее настройки сообщество.
(function() {
   $(".redesigned-group-avatar ").append($(".page_block.page_photo"));
})();
//img_avatar_groups дабавляет.
(function() {
$(".redesigned-group-avatar .AvatarRich").prependTo($("img.page_avatar_img"));
})();