(function() {
jQuery(".left_menu_nav_wrap").prepend("<a class='left_menu_nav' href='/durov' data-stats-key='durov'>Павел Дуров</a>");
})();