(function() {
    'use strict';

	var edit = $("<a>");
	edit.attr("id", "vkc-profile-edit");
	edit.attr("href", "/edit");
	edit.text("");
	edit.appendTo("#l_pr");
})();