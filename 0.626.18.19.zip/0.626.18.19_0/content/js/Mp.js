(function() {
   $("[dir] .audio_page_layout2 .ui_tabs.clear_fix.ui_tabs_header").append('<li class="_audio_section_tab _audio_section_tab_own_playlists_section_tab__playlists"><a onclick="/audios?section=playlists" class="ui_tab" onclick="return uiTabs.goTab(this, event, 0);" data-section-id="">Плейлисты</a></li>')[1];
})();
(function() {
   jQuery("#top_audio_player.top_audio_player_enabled .top_audio_player_title").prepend('.audio_page_player_title');
})();