
(function() {
  'use strict';
  var link = document.querySelector('side_bar_ol');
  link.setAttribute('href', '/settings');
  link.textContent = 'Мои настройки';
  link.id = 'I_sett';
})();