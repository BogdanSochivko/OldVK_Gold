(function() {
    'use strict';
    new MutationObserver(function() {
        $(function() {
            $('.im-right-menu #ui_rmenu_all span').html('Диалоги');
        });
    }).observe(document.body, { childList: true, subtree: true });
})();